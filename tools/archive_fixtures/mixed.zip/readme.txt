WASMIDI archive fixture
